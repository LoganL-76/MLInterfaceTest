import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, jsonb, boolean, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Define enums for better type safety
export const algorithmTypeEnum = z.enum(['patient-volume', 'diagnosis-prediction']);
export const predictionTimeframeEnum = z.enum(['day', 'week', 'month']);
export const statusEnum = z.enum(['pending', 'running', 'completed', 'error']);

export const predictions = pgTable("predictions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  algorithmType: text("algorithm_type").notNull(), // 'patient-volume' or 'diagnosis-prediction'
  predictionTimeframe: text("prediction_timeframe").notNull(), // 'day', 'week', 'month'
  predictionDate: text("prediction_date").notNull(),
  isHoliday: boolean("is_holiday").notNull().default(false),
  dayBeforeHoliday: boolean("day_before_holiday").notNull().default(false),
  dayAfterHoliday: boolean("day_after_holiday").notNull().default(false),
  parameters: jsonb("parameters"), // Store additional algorithm parameters
  results: jsonb("results"), // Store prediction results and metrics
  executionTime: integer("execution_time"), // Execution time in milliseconds
  status: text("status").notNull().default("pending"), // 'pending', 'running', 'completed', 'error'
  error: text("error"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const trainingData = pgTable("training_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  filename: text("filename").notNull(),
  fileSize: integer("file_size").notNull(),
  algorithmType: text("algorithm_type").notNull(),
  dataType: text("data_type").notNull(), // 'training' or 'test'
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  data: jsonb("data"), // Store processed file data
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertPredictionSchema = createInsertSchema(predictions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  algorithmType: algorithmTypeEnum,
  predictionTimeframe: predictionTimeframeEnum,
  status: statusEnum.optional(),
});

export const insertTrainingDataSchema = createInsertSchema(trainingData).omit({
  id: true,
  uploadedAt: true,
}).extend({
  algorithmType: algorithmTypeEnum,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = z.infer<typeof insertPredictionSchema>;
export type TrainingData = typeof trainingData.$inferSelect;
export type InsertTrainingData = z.infer<typeof insertTrainingDataSchema>;
