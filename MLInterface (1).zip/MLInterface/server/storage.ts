import { users, predictions, trainingData, type User, type InsertUser, type Prediction, type InsertPrediction, type TrainingData, type InsertTrainingData } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

// Modified interface with prediction and training data methods
export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Prediction methods
  createPrediction(prediction: InsertPrediction): Promise<Prediction>;
  getPrediction(id: string): Promise<Prediction | undefined>;
  updatePrediction(id: string, updates: Partial<Prediction>): Promise<Prediction>;
  getAllPredictions(): Promise<Prediction[]>;
  
  // Training data methods
  createTrainingData(data: InsertTrainingData): Promise<TrainingData>;
  getTrainingDataByAlgorithm(algorithmType: string): Promise<TrainingData[]>;
  deleteTrainingData(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Prediction methods
  async createPrediction(prediction: InsertPrediction): Promise<Prediction> {
    const [created] = await db
      .insert(predictions)
      .values(prediction)
      .returning();
    return created;
  }

  async getPrediction(id: string): Promise<Prediction | undefined> {
    const [prediction] = await db.select().from(predictions).where(eq(predictions.id, id));
    return prediction || undefined;
  }

  async updatePrediction(id: string, updates: Partial<Prediction>): Promise<Prediction> {
    const [updated] = await db
      .update(predictions)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(predictions.id, id))
      .returning();
    return updated;
  }

  async getAllPredictions(): Promise<Prediction[]> {
    return await db.select().from(predictions);
  }

  // Training data methods
  async createTrainingData(data: InsertTrainingData): Promise<TrainingData> {
    const [created] = await db
      .insert(trainingData)
      .values(data)
      .returning();
    return created;
  }

  async getTrainingDataByAlgorithm(algorithmType: string): Promise<TrainingData[]> {
    return await db.select().from(trainingData).where(eq(trainingData.algorithmType, algorithmType));
  }

  async deleteTrainingData(id: string): Promise<void> {
    await db.delete(trainingData).where(eq(trainingData.id, id));
  }
}

export const storage = new DatabaseStorage();
