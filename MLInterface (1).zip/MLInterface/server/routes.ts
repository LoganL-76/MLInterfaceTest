import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPredictionSchema, insertTrainingDataSchema } from "@shared/schema";
import multer from "multer";
import { z } from "zod";

// Configure multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Prediction endpoints
  app.post("/api/predictions", async (req, res) => {
    try {
      const validatedData = insertPredictionSchema.parse(req.body);
      
      // Create prediction record
      const prediction = await storage.createPrediction({
        ...validatedData,
        status: "running"
      });

      // Simulate algorithm execution
      setTimeout(async () => {
        try {
          const results = await simulateAlgorithmExecution(
            prediction.algorithmType,
            prediction.predictionTimeframe,
            {
              date: prediction.predictionDate,
              isHoliday: prediction.isHoliday,
              dayBeforeHoliday: prediction.dayBeforeHoliday,
              dayAfterHoliday: prediction.dayAfterHoliday
            }
          );

          await storage.updatePrediction(prediction.id, {
            status: "completed",
            results,
            executionTime: Math.floor(Math.random() * 3000) + 500 // 500-3500ms
          });
        } catch (error) {
          await storage.updatePrediction(prediction.id, {
            status: "error",
            error: error instanceof Error ? error.message : "Algorithm execution failed"
          });
        }
      }, 1000);

      res.json(prediction);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Invalid request" });
    }
  });

  app.get("/api/predictions/:id", async (req, res) => {
    try {
      const prediction = await storage.getPrediction(req.params.id);
      if (!prediction) {
        return res.status(404).json({ error: "Prediction not found" });
      }
      res.json(prediction);
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve prediction" });
    }
  });

  app.get("/api/predictions", async (req, res) => {
    try {
      const predictions = await storage.getAllPredictions();
      res.json(predictions);
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve predictions" });
    }
  });

  // File upload endpoints
  app.post("/api/training-data", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const validatedTrainingData = insertTrainingDataSchema.parse({
        filename: req.file.originalname,
        fileSize: req.file.size,
        algorithmType: req.body.algorithmType,
        dataType: req.body.dataType,
        data: null // Will be set below
      });

      // Process file data (simplified - in real implementation would parse CSV/JSON/Excel)
      const fileData = req.file.buffer.toString('utf8');
      let processedData;
      
      try {
        // Try to parse as JSON first
        processedData = JSON.parse(fileData);
      } catch {
        // If not JSON, treat as CSV and convert to simple structure
        const lines = fileData.split('\n').filter(line => line.trim());
        const headers = lines[0]?.split(',') || [];
        processedData = {
          headers,
          rowCount: lines.length - 1,
          preview: lines.slice(0, 6) // First 5 data rows
        };
      }

      const trainingData = await storage.createTrainingData({
        ...validatedTrainingData,
        data: processedData
      });

      res.json(trainingData);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "File upload failed" });
    }
  });

  app.get("/api/training-data/:algorithmType", async (req, res) => {
    try {
      const data = await storage.getTrainingDataByAlgorithm(req.params.algorithmType);
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve training data" });
    }
  });

  app.delete("/api/training-data/:id", async (req, res) => {
    try {
      await storage.deleteTrainingData(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete training data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Simulate algorithm execution with realistic results
async function simulateAlgorithmExecution(
  algorithmType: string,
  timeframe: string,
  parameters: any
): Promise<any> {
  
  if (algorithmType === "patient-volume") {
    // Patient Volume predictions
    const baseVolume = timeframe === "day" ? 120 : timeframe === "week" ? 840 : 3600;
    const holidayMultiplier = parameters.isHoliday ? 0.6 : 
                             parameters.dayBeforeHoliday ? 1.3 : 
                             parameters.dayAfterHoliday ? 1.1 : 1.0;
    
    const predictedVolume = Math.floor(baseVolume * holidayMultiplier * (0.8 + Math.random() * 0.4));
    
    return {
      prediction: {
        expectedPatients: predictedVolume,
        confidenceInterval: `${predictedVolume - 15} - ${predictedVolume + 15}`,
        peakHours: timeframe === "day" ? "14:00 - 16:00" : "Weekends",
        riskLevel: predictedVolume > baseVolume * 1.2 ? "High" : "Normal"
      },
      metrics: [
        { name: "MAE (Mean Absolute Error)", value: "8.3", unit: "patients" },
        { name: "RMSE", value: "12.1", unit: "patients" },
        { name: "R² Score", value: "0.892", unit: "" },
        { name: "Feature Importance", value: "Holiday: 0.34, Day of Week: 0.28", unit: "" }
      ]
    };
  } else {
    // Diagnosis Prediction
    const diagnosisCategories = [
      { diagnosis: "Respiratory Issues", probability: 0.28 },
      { diagnosis: "Cardiac Events", probability: 0.18 },
      { diagnosis: "Trauma/Injury", probability: 0.15 },
      { diagnosis: "Gastrointestinal", probability: 0.12 },
      { diagnosis: "Neurological", probability: 0.10 },
      { diagnosis: "Other", probability: 0.17 }
    ];

    return {
      prediction: {
        topDiagnoses: diagnosisCategories.slice(0, 3),
        riskFactors: ["Seasonal patterns", "Holiday stress", "Weather conditions"],
        recommendedStaffing: {
          emergency: 3,
          cardiology: 2,
          pulmonology: 2
        }
      },
      metrics: [
        { name: "Accuracy", value: "94.2", unit: "%" },
        { name: "Precision", value: "92.8", unit: "%" },
        { name: "Recall", value: "95.1", unit: "%" },
        { name: "F1 Score", value: "93.9", unit: "%" }
      ]
    };
  }
}
