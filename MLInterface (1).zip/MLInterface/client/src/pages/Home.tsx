import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import AlgorithmSelector from '@/components/AlgorithmSelector';
import FileUpload from '@/components/FileUpload';
import ParameterPanel from '@/components/ParameterPanel';
import ResultsDisplay from '@/components/ResultsDisplay';
import ThemeToggle from '@/components/ThemeToggle';

export default function Home() {
  const [selectedAlgorithm, setSelectedAlgorithm] = useState('patient-volume');
  const [selectedFiles, setSelectedFiles] = useState<{[key: string]: File | undefined}>({});
  const [currentPredictionId, setCurrentPredictionId] = useState<string | null>(null);
  
  // Algorithm data
  const algorithms = [
    {
      id: 'patient-volume',
      name: 'Patient Volume',
      description: 'Predictive model for forecasting hospital patient volume and resource allocation needs.',
      category: 'Regression',
      complexity: 'Medium' as const,
      performance: 'Fast' as const
    },
    {
      id: 'diagnosis-prediction',
      name: 'Diagnosis Prediction', 
      description: 'Advanced neural network model for predicting medical diagnoses based on patient symptoms and data.',
      category: 'Classification',
      complexity: 'High' as const,
      performance: 'Medium' as const
    }
  ];

  // Parameters for both algorithms
  const getParametersForAlgorithm = (algorithmId: string) => {
    return [
      { id: 'prediction_timeframe', label: 'Prediction Timeframe', type: 'select' as const, value: 'day', options: ['day', 'week', 'month'] },
      { id: 'date', label: 'Prediction Date', type: 'date' as const, value: new Date().toISOString().split('T')[0] },
      { id: 'is_holiday', label: 'Holiday', type: 'switch' as const, value: false },
      { id: 'day_before_holiday', label: 'Day Before Holiday', type: 'switch' as const, value: false },
      { id: 'day_after_holiday', label: 'Day After Holiday', type: 'switch' as const, value: false }
    ];
  };

  const [parameters, setParameters] = useState(getParametersForAlgorithm(selectedAlgorithm));

  // Query to get current prediction results
  const { data: currentPrediction } = useQuery({
    queryKey: ['prediction', currentPredictionId],
    queryFn: () => currentPredictionId ? `/api/predictions/${currentPredictionId}` : null,
    enabled: !!currentPredictionId,
    refetchInterval: (data) => {
      // Poll every 1 second if prediction is running
      return data?.status === 'running' ? 1000 : false;
    }
  });

  // Mutation to create a new prediction
  const createPredictionMutation = useMutation({
    mutationFn: (predictionData: any) => apiRequest('/api/predictions', 'POST', predictionData),
    onSuccess: (data) => {
      setCurrentPredictionId(data.id);
      console.log('Prediction created:', data.id);
    },
    onError: (error) => {
      console.error('Prediction failed:', error);
    }
  });

  // Mutation to upload training data
  const uploadTrainingDataMutation = useMutation({
    mutationFn: async ({ file, algorithmType, dataType }: { file: File, algorithmType: string, dataType: string }) => {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('algorithmType', algorithmType);
      formData.append('dataType', dataType);
      
      const response = await fetch('/api/training-data', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error('Upload failed');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      console.log('Training data uploaded:', data.filename);
      queryClient.invalidateQueries({ queryKey: ['training-data', selectedAlgorithm] });
    },
    onError: (error) => {
      console.error('Upload failed:', error);
    }
  });

  const handleAlgorithmChange = (algorithmId: string) => {
    setSelectedAlgorithm(algorithmId);
    setParameters(getParametersForAlgorithm(algorithmId));
    setCurrentPredictionId(null); // Reset prediction when changing algorithms
    console.log('Algorithm changed to:', algorithmId);
  };

  const handleParameterChange = (id: string, value: any) => {
    setParameters(prev => prev.map(param => 
      param.id === id ? { ...param, value } : param
    ));
  };

  const handleParameterReset = () => {
    setParameters(getParametersForAlgorithm(selectedAlgorithm));
  };

  const handleRunAlgorithm = () => {
    const predictionTimeframe = parameters.find(p => p.id === 'prediction_timeframe')?.value || 'day';
    const date = parameters.find(p => p.id === 'date')?.value || new Date().toISOString().split('T')[0];
    const isHoliday = parameters.find(p => p.id === 'is_holiday')?.value || false;
    const dayBeforeHoliday = parameters.find(p => p.id === 'day_before_holiday')?.value || false;
    const dayAfterHoliday = parameters.find(p => p.id === 'day_after_holiday')?.value || false;

    createPredictionMutation.mutate({
      algorithmType: selectedAlgorithm,
      predictionTimeframe,
      predictionDate: date,
      isHoliday,
      dayBeforeHoliday,
      dayAfterHoliday,
      parameters: parameters.reduce((acc, param) => {
        acc[param.id] = param.value;
        return acc;
      }, {} as any)
    });
  };

  const handleFileSelect = (type: string, file: File) => {
    setSelectedFiles(prev => ({ ...prev, [type]: file }));
    
    // Auto-upload the file
    uploadTrainingDataMutation.mutate({
      file,
      algorithmType: selectedAlgorithm,
      dataType: type
    });
  };

  const handleFileRemove = (type: string) => {
    setSelectedFiles(prev => ({ ...prev, [type]: undefined }));
  };

  // Get results status and data from current prediction
  const getResultsStatus = () => {
    if (createPredictionMutation.isPending) return 'running';
    if (!currentPrediction) return 'idle';
    return currentPrediction.status as 'idle' | 'running' | 'completed' | 'error';
  };

  const getProgress = () => {
    if (createPredictionMutation.isPending || currentPrediction?.status === 'running') {
      // Simulate progress for running predictions
      return Math.min(90, Date.now() % 100);
    }
    return 100;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur supports-[backdrop-filter]:bg-card/50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Mayo Clinic ER prediction models</h1>
              <p className="text-sm text-muted-foreground">CS Project - Machine Learning Comparison Tool</p>
            </div>
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        <div className="space-y-8">
          {/* Algorithm Selection */}
          <AlgorithmSelector
            algorithms={algorithms}
            selectedAlgorithm={selectedAlgorithm}
            onAlgorithmSelect={handleAlgorithmChange}
          >
            {/* Three Column Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left Column - Parameters */}
              <div>
                <ParameterPanel
                  title={`${algorithms.find(a => a.id === selectedAlgorithm)?.name} Parameters`}
                  parameters={parameters}
                  onParameterChange={handleParameterChange}
                  onReset={handleParameterReset}
                  onRun={handleRunAlgorithm}
                  isRunning={getResultsStatus() === 'running'}
                />
              </div>

              {/* Middle Column - Results */}
              <div>
                <ResultsDisplay
                  algorithmName={algorithms.find(a => a.id === selectedAlgorithm)?.name || 'Algorithm'}
                  status={getResultsStatus()}
                  progress={getProgress()}
                  executionTime={currentPrediction?.executionTime}
                  metrics={currentPrediction?.results?.metrics || []}
                  error={currentPrediction?.error}
                  onExport={() => console.log('Export results')}
                  onViewDetails={() => console.log('View detailed results')}
                />
              </div>

              {/* Right Column - Data Input */}
              <div className="space-y-6">
                <FileUpload
                  title="Training Dataset"
                  acceptedTypes={['.csv', '.json', '.xlsx']}
                  onFileSelect={(file) => handleFileSelect('training', file)}
                  onFileRemove={() => handleFileRemove('training')}
                  selectedFile={selectedFiles.training}
                />
                <FileUpload
                  title="Test Dataset"
                  acceptedTypes={['.csv', '.json', '.xlsx']}
                  onFileSelect={(file) => handleFileSelect('test', file)}
                  onFileRemove={() => handleFileRemove('test')}
                  selectedFile={selectedFiles.test}
                />
              </div>
            </div>
          </AlgorithmSelector>
        </div>
      </main>
    </div>
  );
}