import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Settings, RotateCcw } from 'lucide-react';

interface Parameter {
  id: string;
  label: string;
  type: 'slider' | 'input' | 'select' | 'switch' | 'date';
  value: any;
  min?: number;
  max?: number;
  step?: number;
  options?: string[];
}

interface ParameterPanelProps {
  title: string;
  parameters: Parameter[];
  onParameterChange: (id: string, value: any) => void;
  onReset: () => void;
  onRun: () => void;
  isRunning?: boolean;
}

export default function ParameterPanel({
  title,
  parameters,
  onParameterChange,
  onReset,
  onRun,
  isRunning = false
}: ParameterPanelProps) {
  
  const renderParameter = (param: Parameter) => {
    switch (param.type) {
      case 'slider':
        return (
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor={param.id}>{param.label}</Label>
              <span className="text-sm text-muted-foreground">{param.value}</span>
            </div>
            <Slider
              id={param.id}
              min={param.min || 0}
              max={param.max || 100}
              step={param.step || 1}
              value={[param.value]}
              onValueChange={(value) => {
                onParameterChange(param.id, value[0]);
                console.log(`${param.label} changed to:`, value[0]);
              }}
              data-testid={`slider-${param.id}`}
            />
          </div>
        );
      
      case 'input':
        return (
          <div className="space-y-2">
            <Label htmlFor={param.id}>{param.label}</Label>
            <Input
              id={param.id}
              type="number"
              value={param.value}
              onChange={(e) => {
                const value = parseFloat(e.target.value) || 0;
                onParameterChange(param.id, value);
                console.log(`${param.label} changed to:`, value);
              }}
              data-testid={`input-${param.id}`}
            />
          </div>
        );
      
      case 'select':
        return (
          <div className="space-y-2">
            <Label htmlFor={param.id}>{param.label}</Label>
            <Select value={param.value} onValueChange={(value) => {
              onParameterChange(param.id, value);
              console.log(`${param.label} changed to:`, value);
            }}>
              <SelectTrigger data-testid={`select-${param.id}`}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {param.options?.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        );
      
      case 'switch':
        return (
          <div className="flex items-center justify-between">
            <Label htmlFor={param.id}>{param.label}</Label>
            <Switch
              id={param.id}
              checked={param.value}
              onCheckedChange={(checked) => {
                onParameterChange(param.id, checked);
                console.log(`${param.label} toggled to:`, checked);
              }}
              data-testid={`switch-${param.id}`}
            />
          </div>
        );
      
      case 'date':
        return (
          <div className="space-y-2">
            <Label htmlFor={param.id}>{param.label}</Label>
            <Input
              id={param.id}
              type="date"
              value={param.value}
              onChange={(e) => {
                onParameterChange(param.id, e.target.value);
                console.log(`${param.label} changed to:`, e.target.value);
              }}
              data-testid={`date-${param.id}`}
            />
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          <CardTitle className="text-lg">{title}</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          {parameters.map((param) => (
            <div key={param.id} className="space-y-2">
              {renderParameter(param)}
            </div>
          ))}
        </div>
        
        <div className="flex gap-2 pt-4 border-t">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              onReset();
              console.log('Parameters reset');
            }}
            data-testid="button-reset-parameters"
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset
          </Button>
          <Button
            className="flex-1"
            onClick={() => {
              onRun();
              console.log('Algorithm execution started');
            }}
            disabled={isRunning}
            data-testid="button-run-algorithm"
          >
            {isRunning ? 'Running...' : 'Run Algorithm'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}