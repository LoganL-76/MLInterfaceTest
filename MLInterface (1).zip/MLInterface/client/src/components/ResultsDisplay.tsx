import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, XCircle, Clock, Download, BarChart3 } from 'lucide-react';

interface Metric {
  name: string;
  value: string | number;
  unit?: string;
}

interface ResultsDisplayProps {
  algorithmName: string;
  status: 'idle' | 'running' | 'completed' | 'error';
  progress?: number;
  executionTime?: number;
  metrics?: Metric[];
  error?: string;
  onExport?: () => void;
  onViewDetails?: () => void;
}

export default function ResultsDisplay({
  algorithmName,
  status,
  progress = 0,
  executionTime,
  metrics = [],
  error,
  onExport,
  onViewDetails
}: ResultsDisplayProps) {
  
  const getStatusIcon = () => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-chart-1" />;
      case 'error':
        return <XCircle className="h-5 w-5 text-destructive" />;
      case 'running':
        return <Clock className="h-5 w-5 text-chart-2 animate-spin" />;
      default:
        return <BarChart3 className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const getStatusBadge = () => {
    const variants = {
      idle: 'secondary',
      running: 'default',
      completed: 'default',
      error: 'destructive'
    } as const;

    const labels = {
      idle: 'Ready',
      running: 'Running',
      completed: 'Completed',
      error: 'Error'
    };

    return (
      <Badge variant={variants[status]} className="ml-auto">
        {labels[status]}
      </Badge>
    );
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {getStatusIcon()}
            <CardTitle className="text-lg">{algorithmName} Results</CardTitle>
          </div>
          {getStatusBadge()}
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {status === 'running' && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress</span>
              <span>{progress}%</span>
            </div>
            <Progress value={progress} className="w-full" />
          </div>
        )}

        {status === 'error' && error && (
          <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-md">
            <p className="text-sm text-destructive font-medium">Error</p>
            <p className="text-sm text-muted-foreground mt-1">{error}</p>
          </div>
        )}

        {status === 'completed' && (
          <>
            {executionTime && (
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-sm font-medium">Execution Time</span>
                <span className="text-sm text-muted-foreground" data-testid="text-execution-time">
                  {executionTime}ms
                </span>
              </div>
            )}

            {metrics.length > 0 && (
              <div className="space-y-3">
                <h4 className="font-medium text-sm">Performance Metrics</h4>
                <div className="grid grid-cols-1 gap-3">
                  {metrics.map((metric, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-muted/50 rounded-md">
                      <span className="text-sm font-medium">{metric.name}</span>
                      <span className="text-sm text-muted-foreground" data-testid={`metric-${metric.name.toLowerCase().replace(' ', '-')}`}>
                        {metric.value}{metric.unit && ` ${metric.unit}`}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-2 pt-4 border-t">
              {onViewDetails && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    onViewDetails();
                    console.log('View details clicked for:', algorithmName);
                  }}
                  data-testid="button-view-details"
                >
                  <BarChart3 className="h-4 w-4 mr-2" />
                  View Details
                </Button>
              )}
              {onExport && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    onExport();
                    console.log('Export results clicked for:', algorithmName);
                  }}
                  data-testid="button-export-results"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              )}
            </div>
          </>
        )}

        {status === 'idle' && (
          <div className="text-center py-8 text-muted-foreground">
            <BarChart3 className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p className="text-sm">Run the algorithm to see results here</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}