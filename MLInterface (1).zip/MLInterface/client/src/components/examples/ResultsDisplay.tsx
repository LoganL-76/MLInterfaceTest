import { useState } from 'react';
import ResultsDisplay from '../ResultsDisplay';

export default function ResultsDisplayExample() {
  const [status, setStatus] = useState<'idle' | 'running' | 'completed' | 'error'>('completed');
  
  const completedMetrics = [
    { name: 'Accuracy', value: '94.2', unit: '%' },
    { name: 'Precision', value: '92.8', unit: '%' },
    { name: 'Recall', value: '95.1', unit: '%' },
    { name: 'F1 Score', value: '93.9', unit: '%' }
  ];

  return (
    <div className="max-w-md space-y-4">
      <div className="flex gap-2 mb-4">
        <button 
          onClick={() => setStatus('idle')}
          className="px-3 py-1 text-xs bg-gray-200 rounded"
        >
          Idle
        </button>
        <button 
          onClick={() => setStatus('running')}
          className="px-3 py-1 text-xs bg-blue-200 rounded"
        >
          Running
        </button>
        <button 
          onClick={() => setStatus('completed')}
          className="px-3 py-1 text-xs bg-green-200 rounded"
        >
          Completed
        </button>
        <button 
          onClick={() => setStatus('error')}
          className="px-3 py-1 text-xs bg-red-200 rounded"
        >
          Error
        </button>
      </div>
      
      <ResultsDisplay
        algorithmName="Random Forest"
        status={status}
        progress={status === 'running' ? 67 : 100}
        executionTime={status === 'completed' ? 1240 : undefined}
        metrics={status === 'completed' ? completedMetrics : []}
        error={status === 'error' ? 'Training data format not supported' : undefined}
        onExport={() => console.log('Export triggered')}
        onViewDetails={() => console.log('View details triggered')}
      />
    </div>
  );
}