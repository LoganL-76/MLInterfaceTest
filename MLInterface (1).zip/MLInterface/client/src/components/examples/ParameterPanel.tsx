import { useState } from 'react';
import ParameterPanel from '../ParameterPanel';

export default function ParameterPanelExample() {
  const [parameters, setParameters] = useState([
    { id: 'learning_rate', label: 'Learning Rate', type: 'slider' as const, value: 0.01, min: 0.001, max: 1, step: 0.001 },
    { id: 'epochs', label: 'Epochs', type: 'input' as const, value: 100 },
    { id: 'optimizer', label: 'Optimizer', type: 'select' as const, value: 'adam', options: ['adam', 'sgd', 'rmsprop'] },
    { id: 'early_stopping', label: 'Early Stopping', type: 'switch' as const, value: true }
  ]);
  const [isRunning, setIsRunning] = useState(false);

  const handleParameterChange = (id: string, value: any) => {
    setParameters(prev => prev.map(param => 
      param.id === id ? { ...param, value } : param
    ));
  };

  const handleReset = () => {
    setParameters([
      { id: 'learning_rate', label: 'Learning Rate', type: 'slider' as const, value: 0.01, min: 0.001, max: 1, step: 0.001 },
      { id: 'epochs', label: 'Epochs', type: 'input' as const, value: 100 },
      { id: 'optimizer', label: 'Optimizer', type: 'select' as const, value: 'adam', options: ['adam', 'sgd', 'rmsprop'] },
      { id: 'early_stopping', label: 'Early Stopping', type: 'switch' as const, value: true }
    ]);
  };

  const handleRun = () => {
    setIsRunning(true);
    // Simulate algorithm execution
    setTimeout(() => setIsRunning(false), 3000);
  };

  return (
    <div className="max-w-sm">
      <ParameterPanel
        title="Neural Network Parameters"
        parameters={parameters}
        onParameterChange={handleParameterChange}
        onReset={handleReset}
        onRun={handleRun}
        isRunning={isRunning}
      />
    </div>
  );
}