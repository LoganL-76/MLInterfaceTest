import { useState } from 'react';
import AlgorithmSelector from '../AlgorithmSelector';

export default function AlgorithmSelectorExample() {
  const [selectedAlgorithm, setSelectedAlgorithm] = useState('random-forest');
  
  const algorithms = [
    {
      id: 'random-forest',
      name: 'Random Forest',
      description: 'Ensemble learning method that builds multiple decision trees and merges them for more accurate predictions.',
      category: 'Classification',
      complexity: 'Medium' as const,
      performance: 'Fast' as const
    },
    {
      id: 'neural-network',
      name: 'Neural Network',
      description: 'Deep learning model inspired by biological neural networks for complex pattern recognition.',
      category: 'Classification',
      complexity: 'High' as const,
      performance: 'Medium' as const
    }
  ];

  return (
    <div className="max-w-2xl">
      <AlgorithmSelector
        algorithms={algorithms}
        selectedAlgorithm={selectedAlgorithm}
        onAlgorithmSelect={setSelectedAlgorithm}
      >
        <div className="p-4 bg-muted/50 rounded-md">
          <p className="text-sm text-muted-foreground">
            Configure parameters for {algorithms.find(a => a.id === selectedAlgorithm)?.name} here
          </p>
        </div>
      </AlgorithmSelector>
    </div>
  );
}