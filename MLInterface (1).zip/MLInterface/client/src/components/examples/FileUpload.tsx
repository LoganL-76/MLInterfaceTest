import { useState } from 'react';
import FileUpload from '../FileUpload';

export default function FileUploadExample() {
  const [selectedFile, setSelectedFile] = useState<File | undefined>();

  return (
    <div className="max-w-md">
      <FileUpload
        title="Training Data"
        acceptedTypes={['.csv', '.json', '.xlsx']}
        onFileSelect={setSelectedFile}
        onFileRemove={() => setSelectedFile(undefined)}
        selectedFile={selectedFile}
      />
    </div>
  );
}