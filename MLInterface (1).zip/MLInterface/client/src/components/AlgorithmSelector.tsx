import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Brain, Zap, Target, TrendingUp } from 'lucide-react';

interface Algorithm {
  id: string;
  name: string;
  description: string;
  category: string;
  complexity: 'Low' | 'Medium' | 'High';
  performance: 'Fast' | 'Medium' | 'Slow';
}

interface AlgorithmSelectorProps {
  algorithms: Algorithm[];
  selectedAlgorithm: string;
  onAlgorithmSelect: (algorithmId: string) => void;
  children: React.ReactNode;
}

export default function AlgorithmSelector({
  algorithms,
  selectedAlgorithm,
  onAlgorithmSelect,
  children
}: AlgorithmSelectorProps) {
  
  const getComplexityColor = (complexity: string) => {
    switch (complexity) {
      case 'Low': return 'bg-chart-1/10 text-chart-1 border-chart-1/20';
      case 'Medium': return 'bg-chart-2/10 text-chart-2 border-chart-2/20';
      case 'High': return 'bg-destructive/10 text-destructive border-destructive/20';
      default: return 'bg-muted/10 text-muted-foreground border-muted/20';
    }
  };

  const getPerformanceColor = (performance: string) => {
    switch (performance) {
      case 'Fast': return 'bg-chart-1/10 text-chart-1 border-chart-1/20';
      case 'Medium': return 'bg-chart-2/10 text-chart-2 border-chart-2/20';
      case 'Slow': return 'bg-destructive/10 text-destructive border-destructive/20';
      default: return 'bg-muted/10 text-muted-foreground border-muted/20';
    }
  };

  const getAlgorithmIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'classification':
        return <Target className="h-5 w-5" />;
      case 'regression':
        return <TrendingUp className="h-5 w-5" />;
      case 'clustering':
        return <Brain className="h-5 w-5" />;
      default:
        return <Zap className="h-5 w-5" />;
    }
  };

  return (
    <div className="w-full">
      <Tabs value={selectedAlgorithm} onValueChange={onAlgorithmSelect}>
        <TabsList className="grid w-full grid-cols-2 mb-6">
          {algorithms.map((algorithm) => (
            <TabsTrigger 
              key={algorithm.id} 
              value={algorithm.id}
              data-testid={`tab-${algorithm.id}`}
              className="flex items-center gap-2"
            >
              {getAlgorithmIcon(algorithm.category)}
              {algorithm.name}
            </TabsTrigger>
          ))}
        </TabsList>

        {algorithms.map((algorithm) => (
          <TabsContent key={algorithm.id} value={algorithm.id}>
            <Card className="mb-6">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {getAlgorithmIcon(algorithm.category)}
                      {algorithm.name}
                    </CardTitle>
                    <CardDescription className="mt-2">
                      {algorithm.description}
                    </CardDescription>
                  </div>
                  <div className="flex flex-col gap-2">
                    <Badge 
                      variant="outline" 
                      className={getComplexityColor(algorithm.complexity)}
                    >
                      {algorithm.complexity} Complexity
                    </Badge>
                    <Badge 
                      variant="outline"
                      className={getPerformanceColor(algorithm.performance)}
                    >
                      {algorithm.performance} Performance
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Badge variant="secondary" className="mb-4">
                  {algorithm.category}
                </Badge>
              </CardContent>
            </Card>
            
            <div data-testid={`content-${algorithm.id}`}>
              {children}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}