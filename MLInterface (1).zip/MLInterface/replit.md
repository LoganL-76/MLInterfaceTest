# Machine Learning Algorithm Interface

## Overview

This is a web-based machine learning interface application designed for academic use. The system provides a clean, utility-focused platform for comparing and analyzing ML algorithms with intuitive data input and results visualization. The application follows a system-based design approach inspired by modern productivity tools like Notion and Linear, prioritizing functionality and clear data presentation over visual aesthetics.

The platform supports two main ML algorithms: Patient Volume prediction (for forecasting hospital patient volume and resource allocation) and Diagnosis Prediction (neural network model for medical diagnoses). Users can upload training data, configure algorithm parameters, run predictions, and view detailed results with performance metrics.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend is built with React and TypeScript using Vite as the build tool. The application uses a component-based architecture with shadcn/ui components for consistent UI patterns. Key architectural decisions include:

- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Query (TanStack Query) for server state management with local React state for UI state
- **Styling**: Tailwind CSS with custom design tokens following the academic interface design guidelines
- **Component Library**: Radix UI primitives with shadcn/ui wrapper components for accessibility and consistency
- **Theme System**: Custom theme provider supporting light/dark modes with CSS custom properties

The frontend follows a three-panel layout structure: navigation sidebar, main input/parameter panel, and results panel, with responsive collapse to single column on mobile.

### Backend Architecture
The backend uses Express.js with TypeScript in ESM module format. The architecture follows RESTful API principles with the following structure:

- **Database Layer**: Drizzle ORM with Neon PostgreSQL for type-safe database operations
- **Storage Interface**: Abstracted storage layer (IStorage) allowing for easy database provider switching
- **File Handling**: Multer middleware for file uploads with 10MB size limits
- **API Routes**: Organized route handlers for predictions and training data management
- **Error Handling**: Centralized error handling middleware with proper HTTP status codes

### Data Storage Solutions
The application uses PostgreSQL as the primary database with Drizzle ORM for schema management and migrations. Key database design decisions:

- **Schema Definition**: Strongly typed schemas using Drizzle with Zod validation
- **Tables**: Users, predictions, and training_data tables with JSON columns for flexible parameter and results storage
- **Connection**: Neon serverless PostgreSQL with connection pooling
- **Migrations**: Drizzle Kit for database schema migrations and version control

### Authentication and Authorization
Currently implements a basic user system with username/password authentication. The schema supports user management, though the full authentication flow appears to be prepared but not fully implemented in the current codebase.

### Algorithm Processing
The system simulates ML algorithm execution with the following approach:
- Asynchronous processing with status tracking (pending, running, completed, error)
- Parameter validation using Zod schemas
- Results storage in JSONB format for flexibility
- Execution time tracking and performance metrics

## External Dependencies

### Database and Infrastructure
- **Neon Database**: Serverless PostgreSQL hosting with WebSocket support
- **Drizzle ORM**: Type-safe database toolkit with PostgreSQL dialect
- **Connect PG Simple**: PostgreSQL session store for Express sessions

### Frontend UI and Styling
- **Radix UI**: Comprehensive set of accessible, unstyled UI primitives
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Lucide React**: Icon library for consistent iconography
- **Inter and JetBrains Mono**: Google Fonts for typography (Inter for UI, JetBrains Mono for code/data)

### Development and Build Tools
- **Vite**: Fast build tool and development server with React plugin
- **TypeScript**: Type safety across the full stack
- **ESBuild**: Fast JavaScript bundler for production builds
- **Replit Integration**: Development environment integration with error modal and cartographer plugins

### File Processing and Validation
- **Multer**: File upload handling middleware
- **Zod**: Runtime type validation and schema definition
- **Date-fns**: Date manipulation and formatting utilities

### React Ecosystem
- **React Hook Form**: Form state management with validation
- **TanStack React Query**: Server state management and caching
- **Wouter**: Lightweight routing solution
- **Class Variance Authority**: Utility for managing component variants

The application is designed to be deployed on Replit with environment-specific configurations for development and production modes.